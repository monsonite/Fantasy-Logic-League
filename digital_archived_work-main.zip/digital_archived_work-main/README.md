# digital_archived_work

A repository of multiple projects and sketches created by H. Neemann's "Digital" simulator.

Effectively a dump of all projects from my now very tired laptop hard-drive.
